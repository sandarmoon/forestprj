Download latest file from following link
http://api.textlocal.in/wrappers/php-in.zip

OR
http://api.textlocal.in/docs/phpclass